const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const crypto = require('crypto');
const fs = require('fs');
const config = require('./config.json');

const db = new sqlite3.Database('./sentinel.db');
const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// API - Vérification du token
app.post('/api/verify', (req, res) => {
    const token = req.body.token;
    if (!token) return res.status(400).send('Invalid request.');

    db.get('SELECT * FROM tokens WHERE token = ? AND verified = 0', [token], async (err, row) => {
        if (err) return res.status(500).send('Database error.');
        if (!row) return res.status(403).send('Invalid or expired token.');

        const userId = row.user_id;
        db.run('UPDATE tokens SET verified = 1 WHERE token = ?', [token]);
        db.run('INSERT INTO logs (user_id, action) VALUES (?, ?)', [userId, 'verified']);

        // Trigger Discord bot via local file write (integration point)
        fs.writeFileSync(`./verify_queue/${userId}.verify`, token);

        return res.status(200).send('✅ You have been verified! You can now close this page.');
    });
});

// API - Génération de token (pour le bot)
app.post('/api/token', (req, res) => {
    const { user_id, secret } = req.body;
    if (secret !== config.siteVerificationSecret) return res.status(403).send('Unauthorized.');

    const token = crypto.randomBytes(16).toString('hex');
    db.run('INSERT INTO tokens (token, user_id) VALUES (?, ?)', [token, user_id], err => {
        if (err) return res.status(500).send('Token generation failed.');
        return res.status(200).json({ token });
    });
});

app.listen(PORT, () => {
    console.log(`🌐 Sentinel verification API running at http://localhost:${PORT}`);
});